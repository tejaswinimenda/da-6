```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.holtwinters import ExponentialSmoothing

# Load time series data
# Example: Airline passenger dataset
data = pd.read_csv(r'C:\Users\Menda Tejaswini\OneDrive\Desktop\airline_passengers.csv', index_col='Month', parse_dates=True)

# Visualize the time series data
plt.figure(figsize=(10, 6))
plt.plot(data)
plt.title('Airline Passengers')
plt.xlabel('Year')
plt.ylabel('Number of Passengers')
plt.show()

# Decompose time series into trend, seasonal, and residual components
decomposition = seasonal_decompose(data, model='additive', period=6)
trend = decomposition.trend
seasonal = decomposition.seasonal
residual = decomposition.resid

# Plot decomposition components
plt.figure(figsize=(10, 8))
plt.subplot(411)
plt.plot(data, label='Original')
plt.legend(loc='best')
plt.subplot(412)
plt.plot(trend, label='Trend')
plt.legend(loc='best')
plt.subplot(413)
plt.plot(seasonal, label='Seasonality')
plt.legend(loc='best')
plt.subplot(414)
plt.plot(residual, label='Residuals')
plt.legend(loc='best')
plt.tight_layout()

# Implement forecasting using Exponential Smoothing (Holt-Winters method)
model = ExponentialSmoothing(data, seasonal='add', seasonal_periods=2)
forecast = model.fit().forecast(steps=12)

# Plot original data and forecasted values
plt.figure(figsize=(10, 6))
plt.plot(data, label='Original')
plt.plot(forecast, label='Forecast', linestyle='--')
plt.title('Airline Passengers Forecast')
plt.xlabel('Year')
plt.ylabel('Number of Passengers')
plt.legend(loc='best')
plt.show()


```

    C:\Users\Menda Tejaswini\AppData\Local\Temp\ipykernel_17840\1802238189.py:9: UserWarning: Could not infer format, so each element will be parsed individually, falling back to `dateutil`. To ensure parsing is consistent and as-expected, please specify a format.
      data = pd.read_csv(r'C:\Users\Menda Tejaswini\OneDrive\Desktop\airline_passengers.csv', index_col='Month', parse_dates=True)
    


    
![png](output_0_1.png)
    


    C:\Users\Menda Tejaswini\AppData\Local\Programs\Python\Python312\Lib\site-packages\statsmodels\tsa\base\tsa_model.py:473: ValueWarning: An unsupported index was provided and will be ignored when e.g. forecasting.
      self._init_dates(dates, freq)
    C:\Users\Menda Tejaswini\AppData\Local\Programs\Python\Python312\Lib\site-packages\statsmodels\tsa\base\tsa_model.py:836: ValueWarning: No supported index is available. Prediction results will be given with an integer index beginning at `start`.
      return get_prediction_index(
    C:\Users\Menda Tejaswini\AppData\Local\Programs\Python\Python312\Lib\site-packages\statsmodels\tsa\base\tsa_model.py:836: FutureWarning: No supported index is available. In the next version, calling this method in a model without a supported index will result in an exception.
      return get_prediction_index(
    


    
![png](output_0_3.png)
    



    
![png](output_0_4.png)
    



```python

```
